import { Component } from '@angular/core';
import { MenuBarComponent } from '../../components/menu-bar/menu-bar.component';
import { TitleComponent } from '../../components/menu-title/menu-title.component';
import { SmallCardComponent } from '../../components/smalll-card/small-card.component';
import { BigCardComponent } from '../../components/big-card/big-card.component';
import { ListRenderComponent} from "../../components/list-render/list-render.component";
import {TelaVisualizacaoComponent} from "../../components/tela-visualizacao/tela-visualizacao.component";
import { NavegacaoComponent } from "../../components/navegacao/navegacao.component";
import { LegendasComponent }  from "../../components/legendas/legendas.component";



@Component({
  selector: 'app-home',
  standalone: true,
  imports: [MenuBarComponent,TitleComponent,SmallCardComponent,BigCardComponent,TelaVisualizacaoComponent,ListRenderComponent,NavegacaoComponent,LegendasComponent],
  templateUrl: './home.component.html',
  styleUrl: './home.component.css'
})

export class HomeComponent {
  
}
