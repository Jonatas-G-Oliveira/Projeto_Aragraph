import { Injectable } from "@angular/core";
import { HttpClient } from "@angular/common/http";
import { Observable } from 'rxjs';
import { Passaro } from "../Passaro";


@Injectable({
    providedIn: 'root'
})

export class PassaroService{
    private apiUrl = 'http://44.204.196.53:8080/aves/nome/todas'
    
    
    //NECESSARIIO ADICIONAR UM CONSTRUTOR HTTP PARA FAZER A REQUISOSCAO
    constructor(private http: HttpClient){}
    
    
    //ESSA PARTE NA VERDADE É FEITA POR UM BACK END
    remove(passaros: Passaro[],passaro:Passaro){
        console.log("removendo")
        return passaros.filter((p) => passaro.nomeComum !== p.nomeComum);
    }
    
    getAll():Observable<Passaro[]>{
        //Vamos fazer uma requisição HTTP
        console.log("Fazendo requisição")
        return this.http.get<Passaro[]>(this.apiUrl);
    }
}