import { Component, Input } from "@angular/core";
import { CommonModule } from "@angular/common";
import { SmallCardComponent } from "../smalll-card/small-card.component";

@Component({
    selector:'app-big-card',
    standalone:true,
    imports: [CommonModule, SmallCardComponent],
    templateUrl:'./big-card.component.html',
    styleUrl: './big-card.component.css'
})

export class BigCardComponent {
    lista:string[] = []
    status_exibicao:boolean = false


    //Poderia ser uma lista de objetos passaros
    @Input()
    photoCover:string = "https://cpv.ifsp.edu.br/images/phocagallery/galeria2/thumbs/phoca_thumb_l_image03_grd.png"
    cardName:string = "Urutau - ferrugem"
    cardTaxon = ['Phyllaemulor bracteatus','Jonatus'];
    Passaro = {
        nome: "Urutau",
        taxon: "Uru",
    };

    constructor(){

    }
    adicionarPassaro():void{
        this.lista.push(this.cardName)
        console.log(this.cardName)
        console.log("Adicionado")
    }

    OnChangeView():void{
        this.status_exibicao = !this.status_exibicao
        console.log("VOu mostrar");
        console.log("oaaaa")
    }
    
}