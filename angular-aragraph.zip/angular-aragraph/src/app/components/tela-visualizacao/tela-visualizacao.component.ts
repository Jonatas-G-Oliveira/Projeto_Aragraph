import { Component } from '@angular/core';

@Component({
  selector: 'app-tela-visualizacao',
  standalone: true,
  imports: [],
  templateUrl: './tela-visualizacao.component.html',
  styleUrl: './tela-visualizacao.component.css'
})
export class TelaVisualizacaoComponent {

}
