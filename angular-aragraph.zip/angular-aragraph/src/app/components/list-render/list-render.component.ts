import { Component } from '@angular/core';
import { SmallCardComponent } from '../smalll-card/small-card.component';
import { CommonModule } from '@angular/common';
import { Passaro } from '../../Passaro'
import { PassaroService } from "../../services/busca_passaros";


@Component({
  selector: 'app-list-render',
  standalone: true,
  imports: [SmallCardComponent,CommonModule],
  templateUrl: './list-render.component.html',
  styleUrl: './list-render.component.css'
})

export class ListRenderComponent {
  detalhes:string = ""
  visualizar:boolean = false

  //Responsavel pelos serviços relacionados a api
  constructor(private passaroService: PassaroService){
    //Função para inicializar e pegar os passaros
    /*this.getAllPassaros();*/
  }

  passaros: Passaro[] = [ 
    {
      id:1,
      taxon:"Passarim_tops",
      nomeComum:"Urutau-Bolinha",
      ordem: "string",
      familia: "string",
      genero: "string",
      especie: "string",
      linkAudio: "string",
      linkImg: "https://static.remove.bg/sample-gallery/graphics/bird-thumbnail.jpg",
      linkWiki: "string",
      statusExtincao: "string"
    },
    {
      id:2,
      taxon:"Urutau",
      nomeComum:"Urutau-Rajado",
      ordem: "string",
      familia: "string",
      genero: "string",
      especie: "string",
      linkAudio: "string",
      linkImg: "https://static.remove.bg/sample-gallery/graphics/bird-thumbnail.jpg",
      linkWiki: "string",
      statusExtincao: "string"
    }
  ];

    showTaxon(passaro:Passaro){
      this.visualizar = !this.visualizar;
      this.detalhes = `Taxon: ${passaro.taxon}`
    }


    removePassaro(passaro: Passaro){
      console.log("Teste do remove Service");
      this.passaros = this.passaros.filter(p => (p != passaro))
      /*this.passaros =  this.passaroService.remove(this.passaros,passaro);*/
    }

    /*
    getAllPassaros():void{
      
      //O subscribe é metodo que fecha a requisicao
      //Voce não pode pegar a lista direto
      console.log("implementação do método GET")
      
      this.passaroService.getAll().subscribe((lista) => (this.passaros = lista));
      

      
    }*/
}
