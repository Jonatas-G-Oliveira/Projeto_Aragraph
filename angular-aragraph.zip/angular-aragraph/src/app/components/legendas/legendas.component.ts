import { Component } from '@angular/core';

@Component({
  selector: 'app-legendas',
  standalone: true,
  imports: [],
  templateUrl: './legendas.component.html',
  styleUrl: './legendas.component.css'
})

export class LegendasComponent {

}
