import { Component,Input, Output,EventEmitter } from "@angular/core";



@Component({
   selector:'app-small-card', 
   standalone:true,
   imports: [],
   templateUrl: './small-card.component.html',
   styleUrl: './small-card.component.css'
})

export class SmallCardComponent{
    @Input()
    photoCover:string = "https://static.remove.bg/sample-gallery/graphics/bird-thumbnail.jpg"
    @Input()
    titulo:string = ""
    @Input()
    taxon:string = ""
    

    constructor(
    ){}
  
    @Output() allow_show: EventEmitter<any> = new EventEmitter()
    showBigCard(){
        console.log("MOSTRA O CARD")
        this.allow_show.emit();
        console.log(this.allow_show)
    }
}