export interface Passaro {
    id:number,
    taxon:string,
    nomeComum:string,
    ordem: string,
    familia: string,
    genero: string,
    especie: string,
    linkAudio: string,
    linkImg: string,
    linkWiki: string,
    statusExtincao: string
}